from distutils.core import setup
import py2exe, sys, os
setup(
 version = "1.1",
 #windows = ["tester.py"],
 console = ["milionerzy.py"],
options={
        'py2exe': {
            'packages': [],
            'dist_dir': 'dist',
            'compressed': True,
            "unbuffered": True,
            "optimize": 2,
            "excludes": ["win32evtlog", "win32evtlogutil"]
        }
    }
)